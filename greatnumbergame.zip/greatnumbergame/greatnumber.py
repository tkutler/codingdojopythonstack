from flask import Flask, render_template, request, redirect, session
import random
app = Flask(__name__)
app.secret_key = 'keep it secret, keep it safe' 


@app.route('/')
def choosenum():
    session['randnum'] = random.randint(1,100)
    print(session)
    return render_template("greatnumber.html")


@app.route('/guess', methods= ['POST'])
def guessnum():
    print("user guessed number")
    print(request.form)
    session['guess'] = request.form['guess']
    session['guess'] = int(session['guess'])
    if session['guess'] > session['randnum']:
        return render_template("toohigh.html")
    if session['guess'] < session['randnum']:
        return render_template("toolow.html")
    else:
        return render_template("correct.html")





















if __name__=="__main__":   
    app.run(debug=True) 