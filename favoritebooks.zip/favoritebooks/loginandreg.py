from flask import Flask, render_template, request, redirect, session, flash
from mysqlconnection import connectToMySQL
from flask_bcrypt import Bcrypt 
app = Flask(__name__)
bcrypt= Bcrypt(app)
import re
app.secret_key = "I am a secret key" 
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
db ="books"


@app.route('/')
def index():
    return render_template("index.html")
@app.route('/register', methods= ["POST"])
def register():
    mysql = connectToMySQL(db)
        
    if len(request.form['first']) < 1:
    	flash("Please enter a valid first name")
    if len(request.form['last']) <1:
        flash("Please enter valid last name") 
    if len(request.form["password"]) < 1:
        flash("password lenth must be more than 0 ")
    if len(request.form["passwordconfirm"]) < 1:
        flash("password lenth must be more than 0 ")
    if request.form['password'] != request.form['passwordconfirm']:
        flash ("passsword does not match")
    if not EMAIL_REGEX.match(request.form['email']):
        flash("Invalid email address!")
    if '_flashes' in session.keys():
        return redirect("/")
    if not '_flashes' in session.keys(): 
        pw_hash = bcrypt.generate_password_hash(request.form['password'])
        
        query = "INSERT INTO users (first, last, email, password) VALUES (%(first)s, %(last)s, %(email)s, %(pw)s); "
        data = {
            "first": request.form["first"],
            "last": request.form["last"],
            "email": request.form["email"],
            "pw": pw_hash
        }
        userid = mysql.query_db(query,data)
        session['userid'] = userid
        mysql = connectToMySQL(db)
        query = "SELECT first FROM users WHERE id =" + str(userid)+";"
        username = mysql.query_db(query,data)
        session["username"] = username[0]['first']
        return redirect ("/success")
@app.route("/login", methods = ["POST"]) 
def login():
    mysql = connectToMySQL(db)
    query = "SELECT * FROM users WHERE email = %(email)s;"
    data = {
        "email" : request.form['userlogin']
    }
    users = mysql.query_db(query, data)
    
    
    if users: 
        if bcrypt.check_password_hash(users[0]['password'], request.form['passwordlogin']):
            session['userid'] = users[0]['id']
            session['username'] = users[0]['first']
            print("password found")
            return redirect ('/success')
        else: 
            flash("not successful")
            print("password not found")
            return redirect ("/")
    else: 
        flash("not successful") 
        print("email not found")  
        return redirect ("/")     

@app.route("/success")
def success():
    mysql = connectToMySQL(db)
    query = "SELECT * FROM users WHERE id = "+ str(session['userid']) +";"
    # {
    #     "email" : request.form['userlogin']
    # }
    users = mysql.query_db(query)
     
    print(users)
    mysql = connectToMySQL(db)
    query = "SELECT * from books"
    books = mysql.query_db(query)
    mysql = connectToMySQL(db)
    query = "select * from users JOIN books on users.id = users_id" 
    uploaders = mysql.query_db(query)
   
    return render_template("login.html", users=users[0], uploaders = uploaders) 
@app.route('/logout')
def logout():
    session.clear()
    print('you are logged out')
    return redirect ('/') 
@app.route("/addbook", methods= ["POST"])
def addbook():
    print("i am in the add book route")
    mysql = connectToMySQL(db)
    if len(request.form['title']) < 4:
    	flash("Please enter a valid title") 
    #if no flash messages in session add book to database 
    if not '_flashes' in session.keys(): 
        query = "INSERT INTO books (title, descr, users_id) VALUES (%(title)s, %(descr)s, %(userid)s);"
        data = {
            "title": request.form["title"],
            "descr" : request.form["descr"],
            "userid": request.form["userid"]
        }
        books = mysql.query_db(query,data)
        mysql = connectToMySQL(db)
        query = "INSERT INTO favorites (books_id, users_id) VALUES (" + str(books) + ", " + str(session["userid"]) + ");"
        favorites = mysql.query_db(query)
        print(books)
        return redirect ("/success") 
@app.route("/favorites/<id>")
def addtofav (id): 
    mysql = connectToMySQL(db) 
    print("in fav route")
    query = "INSERT INTO favorites (books_id, users_id) VALUES (" + str(id) + ", " + str(session["userid"]) + ");"
    mysql.query_db(query)
    return redirect ('/success') 
@app.route("/books/<id>")
def bookinfo(id):
    mysql = connectToMySQL(db) 
    print ("in book info route")
    query = "select * from books JOIN users on users.id = books.users_id left outer JOIN favorites ON books.id = favorites.books_id where books.id ="+ id + ";"  
    infos = mysql.query_db(query) 
    print(infos)
    return render_template("bookinfo.html", infos = infos) 
@app.route("/update/<id>", methods= ["POST"])
def updatedescription(id):
    print(id)
    mysql = connectToMySQL(db) 
    print ("in update route")
    query = "UPDATE books SET descr = (%(descr)s) WHERE id="+ id + ";"
    data = {
        "descr": request.form["descr"]
    }
    update = mysql.query_db(query,data) 
    return redirect ("/books/" + id) 
@app.route("/delete/<id>")
def deletebook(id):
    mysql = connectToMySQL(db)
    query = "DELETE FROM books WHERE id="+ id + ";" 
    mysql.query_db(query)
    return redirect ('/books/' + id)


    

















if __name__ == "__main__":
    app.run(debug=True)