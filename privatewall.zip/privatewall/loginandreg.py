from flask import Flask, render_template, request, redirect, session, flash
from mysqlconnection import connectToMySQL
from flask_bcrypt import Bcrypt 
app = Flask(__name__)
bcrypt= Bcrypt(app)
import re
app.secret_key = "I am a secret key" 
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
db ="mydb"


@app.route('/')
def index():
    return render_template("index.html")
@app.route('/register', methods= ["POST"])
def register():
    mysql = connectToMySQL(db)
        
    if len(request.form['first']) < 1:
    	flash("Please enter a valid first name")
    if len(request.form['last']) <1:
        flash("Please enter valid last name") 
    if len(request.form["password"]) < 1:
        flash("password lenth must be more than 0 ")
    if len(request.form["passwordconfirm"]) < 1:
        flash("password lenth must be more than 0 ")
    if request.form['password'] != request.form['passwordconfirm']:
        flash ("passsword does not match")
    if not EMAIL_REGEX.match(request.form['email']):
        flash("Invalid email address!")
    if '_flashes' in session.keys():
        return redirect("/")
    if not '_flashes' in session.keys(): 
        pw_hash = bcrypt.generate_password_hash(request.form['password'])
        
        query = "INSERT INTO users (first, last, email, password) VALUES (%(first)s, %(last)s, %(email)s, %(pw)s); "
        data = {
            "first": request.form["first"],
            "last": request.form["last"],
            "email": request.form["email"],
            "pw": pw_hash
        }
        userid = mysql.query_db(query,data)
        session['userid'] = userid
        return redirect ("/wall")
@app.route("/login", methods = ["POST"]) 
def login():
    mysql = connectToMySQL(db)
    query = "SELECT * FROM users WHERE email = %(email)s;"
    data = {
        "email" : request.form['userlogin']
    }
    users = mysql.query_db(query, data)
    
    
    if users: 
        if bcrypt.check_password_hash(users[0]['password'], request.form['passwordlogin']):
            session['userid'] = users[0]['id']
            session['username'] = users[0]['first']
            print("password found")
            return redirect ('/wall')
        else: 
            flash("not successful")
            print("password not found")
            return redirect ("/")
    else: 
        flash("not successful") 
        print("email not found")  
        return redirect ("/")     

@app.route("/success")
def success():
    mysql = connectToMySQL(db)
    query = "SELECT * FROM users WHERE id = "+ str(session['userid']) +";"
    # {
    #     "email" : request.form['userlogin']
    # }
    users = mysql.query_db(query)
    print(users)
    return render_template("login.html", users=users[0]) 
@app.route('/logout')
def logout():
    session.clear()
    print('you are logged out')
    return redirect ('/') 
@app.route('/wall')
def displaywall():
     mysql = connectToMySQL(db) 
     query = "select messages.id, sender.first, sender.last, messages.content from users as sender join messages on sender.id = sender_id join users as recipient on recipient.id = receipient_id where recipient.id = "+ str(session["userid"])+ ";"
     messages = mysql.query_db(query)
     print(messages)
     mysql= connectToMySQL(db)
     query = "select * from users where id !="+ str(session["userid"])+ ";"
     people = mysql.query_db(query)
     print(people)
     return render_template ("login.html", messages= messages, people = people, meslength = len(messages))


@app.route('/create_message', methods = ['POST'])
def create_message(): 
    mysql= connectToMySQL(db)
    query = "INSERT INTO messages (content, sender_id, receipient_id) VALUES (%(content)s, %(sender_id)s, %(receipient_id)s);"
    data = {
        "content": request.form["message"],
        "sender_id": session["userid"],
        "receipient_id": int(request.form["recipientID"])
    }

    new_friend_id = mysql.query_db(query,data)
    
    return redirect("/wall")

@app.route('/delete/<id>')
def delete(id):
    mysql = connectToMySQL(db)
    query = "DELETE FROM messages WHERE id="+ id + ";" 
    mysql.query_db(query)
    return redirect ('/wall')









if __name__ == "__main__":
    app.run(debug=True)