from flask import Flask, render_template, request, redirect
from mysqlconnection import connectToMySQL
app= Flask(__name__)

db = "friends"

@app.route("/users/new")
def displayadduser():
    return render_template("users.html")

@app.route("/users/create", methods=["POST"])
def create():
    mysql=connectToMySQL(db)


    query = "INSERT INTO friends (first_name, last_name, email, created_at, updated_at) VALUES (%(first_name)s, %(last_name)s, %(email)s, NOW(), NOW());"
    data = {
        "first_name": request.form["first_name"],
        "last_name": request.form["last_name"],
        "email": request.form["email"]
    }

    new_friend_id = mysql.query_db(query,data)
    print(new_friend_id)
    return redirect("/users/" + str(new_friend_id))

@app.route("/users/<id>")
def newUser(id):
    temp = int(id)

    mysql = connectToMySQL(db)
    query = "SELECT * FROM friends WHERE friend_id =%(id)s;"
    data = {
        "id" : id

    }


    friend = mysql.query_db(query,data)[0]
    # run select query using id that was passed in
    # query will return a list of dictionaries containing the user
    return render_template("showuser.html", friend = friend)

@app.route("/users")
def index():
    mysql = connectToMySQL(db)
    query = "SELECT * FROM friends;"
    friends = mysql.query_db(query)
    return render_template("index.html", friends = friends)

@app.route("/users/<id>/edit")
def edituser(id):
    mysql = connectToMySQL(db)
    query = "SELECT * FROM friends WHERE friend_id ="+ id + ";"
    friends = mysql.query_db(query)
    print(friends)
    return render_template("edituser.html", friends = friends[0])

@app.route("/users/<id>/update")
def update(id):
    mysql = connectToMySQL(db)
    query = "UPDATE friends SET first_name = %(fn)s, last_name = %(ln)s, email = %(email)s WHERE id =" + id + ";"
    data = {
        "fn": request.form['first_name'],
        "ln": request.form['last_name'],
        "email": request.form['email']
    }
    mysql.query_db(query)
    return redirect('/users/' + id)  

@app.route ('/users/<id>/destroy') 
def destroy(id):
    mysql = connectToMySQL(db)
    query = "DELETE FROM friends WHERE friend_id =" + id + ";" 
    mysql.query_db(query)
    return redirect('/users') 

if __name__ == "__main__":
    app.run(debug=True)


